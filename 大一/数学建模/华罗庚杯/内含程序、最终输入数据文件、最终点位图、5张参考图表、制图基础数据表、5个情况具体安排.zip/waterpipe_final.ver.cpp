#include <iostream>
using namespace std;
static int dot[174][12];//dot代表节点，0-7位为连接点和对应长度，第8位为状态，0/1/2对应未确定/半确定/全确定，第9位代表cost值,第10位代表它最低cost路径指向的dot，第11位代表最终方案里这条路径的径流量
static int area[112][15];//第0位代表面积，前1-12位代表周围的点集，第13位代表选择的定点，第14位
int output[30]={1,2,3,5,9,10,20,92,95,96,102,105,113,115,117,121,129,132,137,139,156,158,159,160,163,164,166,168,169,170};
//dot和area第0行都没有意义，工具人
static int best[31][3][30],out_pipe[30];//best储存开启1-30个排水口时候的最佳方案和次佳方案；out_pipe储存一个排水口可能性
static long int lowest_cost[31][3];int newtwo[5];//用来记录每次更新新增加的状态2的点的编号
int best_final[31][30];
long int lowest_cost_final[30];
void readdot()//读入dot文件子函数
{	
	FILE *fp = NULL;
	char *line,*record;
	char buffer[1024];
	if ((fp = fopen("dot.csv", "r")) != NULL)
	{
		//fseek(fp, 170L, SEEK_SET);  //定位到第二行，每个英文字符大小为1
		char delims[] = ",";
		char *result = NULL;
		int j = 0;
        int i = 1;
		while ((line = fgets(buffer, sizeof(buffer), fp))!=NULL)//当没有读取到文件末尾时循环继续
		{
			record = strtok(line, ",");
			while (record != NULL)//读取每一行的数据
			{
				//if (strcmp(record, "Ps:") == 0)//当读取到Ps那一行时，不再继续读取
					//return 0;
                if(j!=0) dot[i][j-1]=atoi(record);
                //if(i==10) printf("%d\t%d\t%d\n",dot[i][j-1],i,j-1);
				//printf("%s", record);//将读取到的每一个数据打印出来
				if (j == 9)  //只需读取前9列
					break;
				record = strtok(NULL, ",");
				j++;
			}
			//printf("\n");
			j = 0;
            i++;
		}
		fclose(fp);
		fp = NULL;
	}
}
void readarea()//读入area文件子函数
{	FILE *fp = NULL;
	char *line,*record;
	char buffer[1024];
	if ((fp = fopen("area.csv", "r")) != NULL)
	{
		//fseek(fp, 170L, SEEK_SET);  //定位到第二行，每个英文字符大小为1
		char delims[] = ",";
		char *result = NULL;
		int j = 0;
        int i = 1;
		while ((line = fgets(buffer, sizeof(buffer), fp))!=NULL)//当没有读取到文件末尾时循环继续
		{
			record = strtok(line, ",");
			while (record != NULL)//读取每一行的数据
			{
				//if (strcmp(record, "Ps:") == 0)//当读取到Ps那一行时，不再继续读取
					//return 0;
                if(j!=0) area[i][j-1]=atoi(record);
                //if(i==10) printf("%d\t%d\t%d\n",area[i][j-1],i,j-1);
				//printf("%s", record);//将读取到的每一个数据打印出来
				if (j == 15)  //只需读取前14列
					break;
				record = strtok(NULL, ",");
				j++;
			}
			//printf("\n");
			j = 0;
            i++;
		}
		fclose(fp);
		fp = NULL;
	}
}
void writeExcel_2()//写入结果的子函数
{
	int i ;
	FILE *fp = NULL ;
	fp = fopen("24output.csv","w") ;
    fprintf(fp,"startpoint,endpoint,runoff\n");
	for (i=1 ; i<174 ;i++)
		if(dot[i][11]!=0) fprintf(fp,"%d,%d,%d\n",i,dot[i][10],dot[i][11]) ;
    fprintf(fp,"output:,");
    for(i=1;i<30;i++) if (best_final[24][i]==1) fprintf(fp,"%d,",output[i]);
	fclose(fp);
}
void writeExcel_1()//写入结果的子函数
{
	int i ;
	FILE *fp = NULL ;
	fp = fopen("final_dot.txt","w") ;
    fprintf(fp,"startpoint\t endpoint\t cost\n");
	for (i=1 ; i<174 ;i++)
		fprintf(fp,"%d,%d,%d",i,dot[i][10],dot[i][9]) ;
	fclose(fp);
}
void writeExcel()//写入结果的子函数
{
	int i,j ;
	FILE *fp = NULL ;
	fp = fopen("final.csv","w") ;
    fprintf(fp,"number of output,total cost,increased cost,");
	for (i=1 ; i<31 ;i++)
		{fprintf(fp,"\n%d,%ld,%ld,",i,lowest_cost_final[i],lowest_cost_final[i-1]-lowest_cost_final[i]) ; for(j=0;j<30;j++) fprintf(fp,"%d,",best_final[i][j]);}
	fclose(fp);
}
long int calculate(int a[30])//给定出水口以后计算最小cost和路径
{
    int i,j,k,l,newboy,newgirl,exchange;//工具变量
    //static int output[30]={166,164,129,167,121,115,113,92,95,96,160,5,3,163,137,139,168,117,105,102,10,20,9,1,2,169,156,158,159,132,170};//所有出水口下标
    for(i=1;i<174;i++) dot[i][8]=0;//初始化状态
    for(i=1;i<174;i++) dot[i][11]=0;//初始径流量
    for(i=1;i<174;i++) dot[i][10]=0;//初始化路径指向
    for(i=1;i<174;i++) dot[i][9]=2147483646;//初始化cost
    for(i=1;i<112;i++) {area[i][13]=0;area[i][14]=0;}//初始化area
    for(i=0;i<30;i++) if(a[i]==1 && output[i]!=0) {dot[output[i]][8]=1; dot[output[i]][9]=0; dot[output[i]][10]=-1;}//设定出水口cost为0，状态为1，指向-1节点
    for(int sign=0;sign==0;)//开始循环更新cost 路径
    {
        j=0; l=2147483647;
        for(i=1;i<174;i++)//寻找要更新的中心点，也就是cost最小的点
        {
            if (dot[i][8]!=1) continue;//只考虑状态为1的点
            if (dot[i][9]<l) {j=i;l=dot[i][9];}
        }
        dot[j][8]=2;
        for (i=0;i<4;i++)
        {
            if (dot[j][i*2]==0) continue;//判断是否通向真实节点
            newboy=dot[j][i*2];//方便下面语法
            if (dot[newboy][8]!=0) {if (dot[j][9]+dot[j][i*2+1]<dot[newboy][9]) {dot[newboy][9]=dot[j][9]+dot[j][i*2+1];dot[newboy][10]=j;}}
            if (dot[newboy][8]==0)
            {
                dot[dot[j][i*2]][9]=dot[j][9]+dot[j][i*2+1];dot[dot[j][i*2]][10]=j;//先把这个点的cost 路径更新了，然后开始考虑变成2的所有点
                for(k=0;k<4;k++) //先判断newboy相邻点是否为变为2
                {
                    if(dot[newboy][2*k]==0) {newtwo[k]=0;continue;}//是否通往真实节点
                    if(dot[dot[newboy][2*k]][8]==0) {newtwo[k]=0;continue;}//是否通往已确定cost的节点
                    newgirl=dot[newboy][2*k];
                    sign=0;
                    for(l=0;l<4;l++) if (dot[newgirl][2*l]!=0 && dot[dot[newgirl][2*l]][8]==0) sign=1; 
                    if (sign==0) {dot[newgirl][8]=2;newtwo[k]=newgirl;}
                } 
                sign=0;
                for(l=0;l<4;l++) if (dot[newboy][2*l]!=0 && dot[dot[newboy][2*l]][8]==0) sign=1;//判断newboy是否变为2 
                if (sign==0) {dot[newboy][8]=2;newtwo[4]=newboy;} else {dot[newboy][8]=1;newtwo[4]=0;}
                for(k=4;k>0;k--)//按照cost大小将newtwo数组里面节点排序
                    for(l=0;l<k;l++) if (dot[newtwo[l]][9]>dot[newtwo[l+1]][9]) {exchange=newtwo[l];newtwo[l]=newtwo[l+1];newtwo[l+1]=exchange;}
                for(k=0;k<4;k++)
                {
                    if (newtwo[k]==0) continue;
                    for (l=0;l<4;l++)
                    {
                        if (dot[newtwo[k]][l*2]==0) continue;
                        if (dot[newtwo[k]][9]>dot[dot[newtwo[k]][l*2]][9]+dot[newtwo[k]][2*l+1]) {dot[newtwo[k]][9]=dot[dot[newtwo[k]][l*2]][9]+dot[newtwo[k]][2*l+1];dot[newtwo[k]][10]=dot[newtwo[k]][2*l];}
                    }
                }
                for(l=0;l<5;l++) newtwo[l]=0;
            }
        }
        sign=1;
        for(i=1;i<174;i++) if (dot[i][8]!=2) {sign=0;break;}//判断是否已经完成全部计算
    }
    for (int reexam=1;reexam<174;reexam++)//重新更新一次dot
    {
        l=2147483647;
        j=0;
        for(i=1;i<174;i++)//找到当前未确定的最低的dot[j]
            if (dot[i][8]==2 && dot[i][9]<l) {j=i;l=dot[i][9];}
        dot[j][8]=3;
        for (l=0;l<4;l++)//更新dot[j]的cost 和路径
        {
            if (dot[j][l*2]==0) continue;
            if (dot[j][9]>dot[dot[j][l*2]][9]+dot[j][2*l+1]) {dot[j][9]=dot[dot[j][l*2]][9]+dot[j][2*l+1];dot[newtwo[k]][10]=dot[j][2*l];}
        }
    }
    //以上完成所有dot的cost 计算
    //for(i=1;i<174;i++) printf("%d\t%d\t%d\n",i,dot[i][10],dot[i][9]);
    //writeExcel_1();
    for (int ass=1;ass<112;ass++)//完成对所有区域轨迹的叠加
    {
        area[ass][14]=2147483646;
        for(i=1;i<13;i++) if(dot[area[ass][i]][9]<area[ass][14] && area[ass][i]!=0) {area[ass][13]=area[ass][i];area[ass][14]=dot[area[ass][i]][9];}
        j=area[ass][13];for(;dot[j][10]!=-1;){dot[j][11]+=area[ass][0];j=dot[j][10];}
        //printf("%d\t%d\t%d\n",ass,area[ass][13],area[ass][14]);
    }
    //writeExcel_2();//将结果输出
    i=0;
    for (int ass=1;ass<112;ass++) i+=area[ass][14]*area[ass][0];
    return i;
}

int main()
{
    readdot();
    readarea();
    int i,j,l;//工具变量
    long int k;
    for (i=1;i<31;i++) lowest_cost[i][0]=lowest_cost[i][1]=lowest_cost[i][2]=500000000000;
    for (i=0;i<30;i++) best[0][0][i]=best[0][1][i]=best[0][2][i]=0;
    //lowest_cost[30][0]=lowest_cost[30][1]=lowest_cost[30][2]=calculate(best[30][0]);
    for (i=1;i<31;i++)
    {
        if (i==3) {for (j=0;j<30;j++) out_pipe[j]=0;out_pipe[9]=out_pipe[27]=1;memcpy(best[i-1][0],out_pipe,sizeof(out_pipe));lowest_cost[2][0]=calculate(out_pipe);}
        memcpy(out_pipe,best[i-1][0],sizeof(best[i-1][0]));//根据i+1时最佳方案调整
        for(j=0;j<30;j++)
        {
            if(out_pipe[j]==1) continue;
            out_pipe[j]=1;
            k=calculate(out_pipe);
            if(k<lowest_cost[i][2]&&k>=lowest_cost[i][1])
            {
                memcpy(best[i][2],out_pipe,sizeof(out_pipe));lowest_cost[i][2]=k;
            }
            if (k<lowest_cost[i][1])
            {
                if (k<lowest_cost[i][0]) 
                {
                    memcpy(best[i][2],best[i][1],sizeof(best[i][1]));memcpy(best[i][1],best[i][0],sizeof(best[i][0]));memcpy(best[i][0],out_pipe,sizeof(out_pipe));
                    lowest_cost[i][2]=lowest_cost[i][1];lowest_cost[i][1]=lowest_cost[i][0];lowest_cost[i][0]=k;
                }
                else 
                {
                    memcpy(best[i][2],best[i][1],sizeof(best[i][1]));memcpy(best[i][1],out_pipe,sizeof(out_pipe));
                    lowest_cost[i][2]=lowest_cost[i][1];lowest_cost[i][1]=k;
                }
            }
            out_pipe[j]=0;
        }
        memcpy(out_pipe,best[i-1][1],sizeof(best[i-1][1]));//根据i+1时最佳方案调整
        for(j=0;j<30;j++)
        {
            if(out_pipe[j]==1) continue;
            out_pipe[j]=1;
            k=calculate(out_pipe);
            if(k<lowest_cost[i][2]&&k>=lowest_cost[i][1])
            {
                memcpy(best[i][2],out_pipe,sizeof(out_pipe));lowest_cost[i][2]=k;
            }
            if (k<lowest_cost[i][1])
            {
                if (k<lowest_cost[i][0]) 
                {
                    memcpy(best[i][2],best[i][1],sizeof(best[i][1]));memcpy(best[i][1],best[i][0],sizeof(best[i][0]));memcpy(best[i][0],out_pipe,sizeof(out_pipe));
                    lowest_cost[i][2]=lowest_cost[i][1];lowest_cost[i][1]=lowest_cost[i][0];lowest_cost[i][0]=k;
                }
                else 
                {
                    memcpy(best[i][2],best[i][1],sizeof(best[i][1]));memcpy(best[i][1],out_pipe,sizeof(out_pipe));
                    lowest_cost[i][2]=lowest_cost[i][1];lowest_cost[i][1]=k;
                }
            }
            out_pipe[j]=0;
        }
        memcpy(out_pipe,best[i-1][2],sizeof(best[i-1][2]));//根据i+1时最佳方案调整
        for(j=0;j<30;j++)
        {
            if(out_pipe[j]==1) continue;
            out_pipe[j]=1;
            k=calculate(out_pipe);
            if(k<lowest_cost[i][2]&&k>=lowest_cost[i][1])
            {
                memcpy(best[i][2],out_pipe,sizeof(out_pipe));lowest_cost[i][2]=k;
            }
            if (k<lowest_cost[i][1])
            {
                if (k<lowest_cost[i][0]) 
                {
                    memcpy(best[i][2],best[i][1],sizeof(best[i][1]));memcpy(best[i][1],best[i][0],sizeof(best[i][0]));memcpy(best[i][0],out_pipe,sizeof(out_pipe));
                    lowest_cost[i][2]=lowest_cost[i][1];lowest_cost[i][1]=lowest_cost[i][0];lowest_cost[i][0]=k;
                }
                else 
                {
                    memcpy(best[i][2],best[i][1],sizeof(best[i][1]));memcpy(best[i][1],out_pipe,sizeof(out_pipe));
                    lowest_cost[i][2]=lowest_cost[i][1];lowest_cost[i][1]=k;
                }
            }
            out_pipe[j]=0;
        }
        
    }
  
    //for(i=0;i<30;i++) if(best[24][0][i]==0) printf("%d\t",output[i]);
    //printf("\n%ld\n%ld\n",lowest_cost[29][0],lowest_cost[29][1]);
    long int lowest_cost_reverse[30][1];
    int best_reverse[31][1][30];
    for (i=1;i<31;i++) {memcpy(best_reverse[i][0], best[i][0],sizeof(best[i][0]));lowest_cost_reverse[i][0]=lowest_cost[i][0];}
    for (i=1;i<30;i++) lowest_cost[i][0]=lowest_cost[i][1]=lowest_cost[i][2]=500000000000;
    for (i=0;i<30;i++) best[30][0][i]=best[30][1][i]=best[30][2][i]=1;
    lowest_cost[30][0]=lowest_cost[30][1]=lowest_cost[30][2]=calculate(best[30][0]);
    for (i=29;i>0;i--)
    {
        memcpy(out_pipe,best[i+1][0],sizeof(best[i+1][0]));//根据i+1时最佳方案调整
        for(j=0;j<30;j++)
        {
            if(out_pipe[j]==0) continue;
            out_pipe[j]=0;
            k=calculate(out_pipe);
            if(k<lowest_cost[i][2]&&k>=lowest_cost[i][1])
            {
                memcpy(best[i][2],out_pipe,sizeof(out_pipe));lowest_cost[i][2]=k;
            }
            if (k<lowest_cost[i][1])
            {
                if (k<lowest_cost[i][0]) 
                {
                    memcpy(best[i][2],best[i][1],sizeof(best[i][1]));memcpy(best[i][1],best[i][0],sizeof(best[i][0]));memcpy(best[i][0],out_pipe,sizeof(out_pipe));
                    lowest_cost[i][2]=lowest_cost[i][1];lowest_cost[i][1]=lowest_cost[i][0];lowest_cost[i][0]=k;
                }
                else 
                {
                    memcpy(best[i][2],best[i][1],sizeof(best[i][1]));memcpy(best[i][1],out_pipe,sizeof(out_pipe));
                    lowest_cost[i][2]=lowest_cost[i][1];lowest_cost[i][1]=k;
                }
            }
            out_pipe[j]=1;
        }
        memcpy(out_pipe,best[i+1][1],sizeof(best[i+1][1]));//根据i+1时最佳方案调整
        for(j=0;j<30;j++)
        {
            if(out_pipe[j]==0) continue;
            out_pipe[j]=0;
            k=calculate(out_pipe);
            if(k<lowest_cost[i][2]&&k>=lowest_cost[i][1])
            {
                memcpy(best[i][2],out_pipe,sizeof(out_pipe));lowest_cost[i][2]=k;
            }
            if (k<lowest_cost[i][1])
            {
                if (k<lowest_cost[i][0]) 
                {
                    memcpy(best[i][2],best[i][1],sizeof(best[i][1]));memcpy(best[i][1],best[i][0],sizeof(best[i][0]));memcpy(best[i][0],out_pipe,sizeof(out_pipe));
                    lowest_cost[i][2]=lowest_cost[i][1];lowest_cost[i][1]=lowest_cost[i][0];lowest_cost[i][0]=k;
                }
                else 
                {
                    memcpy(best[i][2],best[i][1],sizeof(best[i][1]));memcpy(best[i][1],out_pipe,sizeof(out_pipe));
                    lowest_cost[i][2]=lowest_cost[i][1];lowest_cost[i][1]=k;
                }
            }
            out_pipe[j]=1;
        }
        memcpy(out_pipe,best[i+1][2],sizeof(best[i+1][2]));//根据i+1时最佳方案调整
        for(j=0;j<30;j++)
        {
            if(out_pipe[j]==0) continue;
            out_pipe[j]=0;
            k=calculate(out_pipe);
            if(k<lowest_cost[i][2]&&k>=lowest_cost[i][1])
            {
                memcpy(best[i][2],out_pipe,sizeof(out_pipe));lowest_cost[i][2]=k;
            }
            if (k<lowest_cost[i][1])
            {
                if (k<lowest_cost[i][0]) 
                {
                    memcpy(best[i][2],best[i][1],sizeof(best[i][1]));memcpy(best[i][1],best[i][0],sizeof(best[i][0]));memcpy(best[i][0],out_pipe,sizeof(out_pipe));
                    lowest_cost[i][2]=lowest_cost[i][1];lowest_cost[i][1]=lowest_cost[i][0];lowest_cost[i][0]=k;
                }
                else 
                {
                    memcpy(best[i][2],best[i][1],sizeof(best[i][1]));memcpy(best[i][1],out_pipe,sizeof(out_pipe));
                    lowest_cost[i][2]=lowest_cost[i][1];lowest_cost[i][1]=k;
                }
            }
            out_pipe[j]=1;
        }
    }
     // for(i=1;i<31;i++)printf("%d\t%ld\t%ld\t%ld\n",i,lowest_cost[i][0],lowest_cost[i][1],lowest_cost_reverse[i][0]);
     for(i=1;i<31;i++) 
     {
         if (lowest_cost[i][0]<lowest_cost_reverse[i][0]) {memcpy(best_final[i],best[i][0],sizeof(best[i][0]));lowest_cost_final[i]=lowest_cost[i][0];}
         else  {memcpy(best_final[i],best_reverse[i][0],sizeof(best_reverse[i][0]));lowest_cost_final[i]=lowest_cost_reverse[i][0];}
     }
    lowest_cost_final[0]=lowest_cost_final[1];
    //writeExcel();
    //calculate(best_final[24]);
    //writeExcel_2();
    for(i=1;i<31;i++){printf("\n%d\t%ld\t ",i,lowest_cost_final[i]);for(j=0;j<30;j++) printf("%d",best_final[i][j]);if(i!=1) printf("\t%ld",lowest_cost_final[i-1]-lowest_cost_final[i]);}
    return 0;
}