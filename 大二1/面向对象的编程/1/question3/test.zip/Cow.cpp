#include"Cow.h"
#include<string>
using namespace std;

Cow::Cow(string a,int b,int c,int d)
{
    name=a;
    low=b,high=c,milk=d;
}