clear all; close all; clc;

realsong=audioread("fmt.wav");%读取音乐文件
sound(realsong);%播放音乐